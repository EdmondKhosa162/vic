package za.co.vic.VIC_Company;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VicCompanyApplicationTests {

	@Test
	void contextLoads() {
	}

}
